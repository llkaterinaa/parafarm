public class Employee {

    private int employeeId;
    private String firstName;
    private String lastName;
    private String position;
    private String phone;

    public Employee(int employeeId, String firstName, String lastName,
                    String position, String phone) {

        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.position = position;
        this.phone = phone;
    }

    public String getLastName() {
        return lastName;
    }

    public void printData() {
        System.out.println("Employee: " + firstName + " " + lastName);
        System.out.println("Position: " + position);
    }
}