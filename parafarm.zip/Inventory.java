import java.util.Date;

public class Inventory {

    private int inventoryId;
    private Date lastUpdated;

    public Inventory(int inventoryId, Date lastUpdated) {
        this.inventoryId = inventoryId;
        this.lastUpdated = lastUpdated;
    }

    public void printData() {
        System.out.println("Inventory ID: " + inventoryId);
        System.out.println("Last Updated: " + lastUpdated);
    }
}