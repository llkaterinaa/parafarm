public class OrderItem {

    private Product product;
    private int quantity;
    private double subtotal;

    public OrderItem(Product product, int quantity) {

        this.product = product;
        this.quantity = quantity;

        subtotal = product.getPrice() * quantity;

        product.reduceStock(quantity);
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void printData() {

        System.out.println(product.getName() +
                " Quantity: " + quantity +
                " Subtotal: " + subtotal);
    }
}