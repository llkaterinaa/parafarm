import java.util.Date;

public class Invoice {

    private int invoiceId;
    private Date issueDate;
    private double totalAmount;

    public Invoice(int invoiceId,
                   Date issueDate,
                   double totalAmount) {

        this.invoiceId = invoiceId;
        this.issueDate = issueDate;
        this.totalAmount = totalAmount;
    }

    public void printData() {
        System.out.println("Invoice ID: " + invoiceId);
        System.out.println("Total: " + totalAmount);
    }
}