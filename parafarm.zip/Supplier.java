public class Supplier {

    private int supplierId;
    private String name;
    private String phone;
    private String email;

    public Supplier(int supplierId, String name,
                    String phone, String email) {

        this.supplierId = supplierId;
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    public void printData() {
        System.out.println("Supplier: " + name);
    }
}