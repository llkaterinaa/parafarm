import java.util.ArrayList;
import java.util.Date;

public class Order {

    private int orderId;
    private Date orderDate;
    private String status;
    private double totalAmount;

    private Customer customer;
    private Employee employee;

    private ArrayList<OrderItem> items;

    public Order(int orderId,
                 Date orderDate,
                 String status,
                 Customer customer,
                 Employee employee) {

        this.orderId = orderId;
        this.orderDate = orderDate;
        this.status = status;
        this.customer = customer;
        this.employee = employee;

        items = new ArrayList<>();
    }

    public void addItem(OrderItem item) {

        items.add(item);
        totalAmount += item.getSubtotal();
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void printData() {

        System.out.println("Order ID: " + orderId);
        System.out.println("Customer: " + customer.getName());
        System.out.println("Employee: " + employee.getLastName());

        for(OrderItem item : items) {
            item.printData();
        }

        System.out.println("Total: " + totalAmount);
    }
}