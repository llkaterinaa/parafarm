import java.util.ArrayList;
import java.util.Date;

public class Main {

    public static void main(String[] args) {

        ArrayList<Product> products = new ArrayList<>();
        ArrayList<Customer> customers = new ArrayList<>();
        ArrayList<Employee> employees = new ArrayList<>();
        ArrayList<Order> orders = new ArrayList<>();
        ArrayList<SupplierOrder> supplierOrders = new ArrayList<>();

        // =========================
        // PRODUCTS
        // =========================

        Product product1 =
                new Product(1,"Thermometer",
                        "paramedical",12.50,80,30);

        Product product2 =
                new Product(2,"Shoes",
                        "paramedical",35.00,45,20);

        Product product3 =
                new Product(3,"Cream",
                        "cosmetic",18.00,25,40);

        Product product4 =
                new Product(4,"Makeup",
                        "cosmetic",22.00,60,25);

        products.add(product1);
        products.add(product2);
        products.add(product3);
        products.add(product4);

        System.out.println("Object product1 has been created");
        System.out.println("Object product2 has been created");
        System.out.println("Object product3 has been created");
        System.out.println("Object product4 has been created");

        // =========================
        // CUSTOMERS
        // =========================

        Customer customer1 =
                new Customer(
                        1,
                        "Farmakeio Papadopoulou",
                        "Kalamaria",
                        "099845210",
                        "papadopoulou@email.gr"
                );

        Customer customer2 =
                new Customer(
                        2,
                        "Farmakeio Nikolaidis",
                        "Evosmos",
                        "078632145",
                        "nikolaidis@email.gr"
                );

        Customer customer3 =
                new Customer(
                        3,
                        "Georgiou Maria",
                        "Thessaloniki",
                        "112233445",
                        "maria@email.gr"
                );

        customers.add(customer1);
        customers.add(customer2);
        customers.add(customer3);

        System.out.println("Customers created successfully");

        // =========================
        // EMPLOYEES
        // =========================

        Employee employee1 =
                new Employee(
                        1,
                        "",
                        "Antoniou",
                        "Warehouse",
                        "warehouse_user"
                );

        Employee employee2 =
                new Employee(
                        2,
                        "",
                        "Eleftheriou",
                        "Customer Service",
                        "service_user"
                );

        Employee employee3 =
                new Employee(
                        3,
                        "",
                        "Sotiriou",
                        "Cashier",
                        "cashier_user"
                );

        Employee employee4 =
                new Employee(
                        4,
                        "",
                        "Seller1",
                        "Sales",
                        "sales_user"
                );

        employees.add(employee1);
        employees.add(employee2);
        employees.add(employee3);
        employees.add(employee4);

        System.out.println("Employees created successfully");

        // =========================
        // ORDER 1
        // =========================

        Order order1 =
                new Order(
                        1,
                        new Date(),
                        "Completed",
                        customer1,
                        employee4
                );

        order1.addItem(
                new OrderItem(product1,10));

        order1.addItem(
                new OrderItem(product3,5));

        orders.add(order1);

        // =========================
        // ORDER 2
        // =========================

        Order order2 =
                new Order(
                        2,
                        new Date(),
                        "Completed",
                        customer1,
                        employee4
                );

        order2.addItem(
                new OrderItem(product2,8));

        order2.addItem(
                new OrderItem(product4,12));

        orders.add(order2);

        // =========================
        // ORDER 3
        // =========================

        Order order3 =
                new Order(
                        3,
                        new Date(),
                        "Completed",
                        customer2,
                        employee4
                );

        order3.addItem(
                new OrderItem(product3,20));

        order3.addItem(
                new OrderItem(product4,10));

        order3.addItem(
                new OrderItem(product1,6));

        orders.add(order3);

        // =========================
        // ORDER 4
        // =========================

        Order order4 =
                new Order(
                        4,
                        new Date(),
                        "Completed",
                        customer3,
                        employee3
                );

        order4.addItem(
                new OrderItem(product1,1));

        order4.addItem(
                new OrderItem(product4,2));

        orders.add(order4);

        System.out.println("Orders created successfully");

        // =========================
        // DELETE ORDER2
        // =========================

        orders.remove(order2);

        System.out.println("Order2 deleted successfully");

        // =========================
        // CHECK STOCK
        // =========================

        int supplierOrderCounter = 1;

        for(Product p : products){

            if(p.getStockQuantity()
                    < p.getSafetyStock()){

                SupplierOrder supplierOrder =
                        new SupplierOrder(
                                supplierOrderCounter++,
                                p,
                                50,
                                "Stock below safety limit"
                        );

                supplierOrders.add(
                        supplierOrder);

                System.out.println(
                        "Supplier order created for "
                                + p.getName()
                );
            }
        }

        // =========================
        // PRINT PRODUCTS
        // =========================

        System.out.println("\nPRODUCT LIST");

        for(Product p : products){
            p.printData();
        }

        // =========================
        // PRINT CUSTOMERS
        // =========================

        System.out.println("\nCUSTOMER LIST");

        for(Customer c : customers){
            c.printData();
        }

        // =========================
        // PRINT EMPLOYEES
        // =========================

        System.out.println("\nEMPLOYEE LIST");

        for(Employee e : employees){
            e.printData();
        }

        // =========================
        // PRINT ORDERS
        // =========================

        System.out.println("\nORDER LIST");

        for(Order o : orders){
            o.printData();
        }

        // =========================
        // PRINT SUPPLIER ORDERS
        // =========================

        System.out.println(
                "\nSUPPLIER ORDER LIST");

        for(SupplierOrder so :
                supplierOrders){

            so.printData();
        }

        System.out.println(
                "\nProgram executed successfully");
    }
}