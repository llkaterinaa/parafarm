
public class User {

    private int userId;
    private String username;
    private String password;
    private String role;

    public User(int userId, String username, String password, String role) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public void printData() {
        System.out.println("User: " + username + " Role: " + role);
    }
}