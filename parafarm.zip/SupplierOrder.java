public class SupplierOrder {

    private int supplierOrderId;
    private Product product;
    private int quantity;
    private String reason;

    public SupplierOrder(int supplierOrderId,
                         Product product,
                         int quantity,
                         String reason) {

        this.supplierOrderId = supplierOrderId;
        this.product = product;
        this.quantity = quantity;
        this.reason = reason;
    }

    public void printData() {

        System.out.println("Supplier Order ID: "
                + supplierOrderId);

        System.out.println("Product: "
                + product.getName());

        System.out.println("Quantity: "
                + quantity);

        System.out.println("Reason: "
                + reason);

        System.out.println("------------------");
    }
}