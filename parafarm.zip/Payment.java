import java.util.Date;

public class Payment {

    private int paymentId;
    private Date paymentDate;
    private double amount;
    private String paymentMethod;

    public Payment(int paymentId,
                   Date paymentDate,
                   double amount,
                   String paymentMethod) {

        this.paymentId = paymentId;
        this.paymentDate = paymentDate;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
    }

    public void printData() {
        System.out.println("Payment: " + amount);
        System.out.println("Method: " + paymentMethod);
    }
}