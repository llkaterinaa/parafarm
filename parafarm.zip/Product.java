public class Product {

    private int productId;
    private String name;
    private String category;
    private double price;
    private int stockQuantity;
    private int safetyStock;

    public Product(int productId,
                   String name,
                   String category,
                   double price,
                   int stockQuantity,
                   int safetyStock) {

        this.productId = productId;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.safetyStock = safetyStock;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public int getSafetyStock() {
        return safetyStock;
    }

    public void reduceStock(int quantity) {
        stockQuantity -= quantity;
    }

    public void printData() {
        System.out.println("Product: " + name);
        System.out.println("Category: " + category);
        System.out.println("Price: " + price);
        System.out.println("Stock: " + stockQuantity);
        System.out.println("Safety Stock: " + safetyStock);
    }
}